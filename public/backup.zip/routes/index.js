var paths = require('../paths')
	, fs = require('fs')
	, path = require('path')
	, build = require('../build').build
	, shout = require('../shout').shout
	, showdown = require('showdown')
	, nsh = require('node-syntaxhighlighter')
	, highlight = require('highlight').Highlight
	, markdown = new showdown.converter();
/*
 * Home page
 */
exports.index = function(req, res) {
	res.render('index', {
		title: [],
		page: 'home'
	});
}

/*
 * About
 */
exports.about = function(req, res) {
	res.render('about', {
		title: ['About'],
		page: 'about'
	})
}

/*
 * Demos
 */
exports.demos = function(req, res, next) {
	var demo = req.params.demo || '',
		download = req.params.download || 'undefined' !== typeof req.query['download'],
		source = req.params.source || 'undefined' !== typeof req.query['source'],
		props = {
			title: ['Demos'],
			page: 'demos',
			demo: demo
		};

	// Pass IP through on Geolocation demo
	if(demo === 'geolocation') {
		try {
			props.IP = req.headers['x-forwarded-for'];
		}
		catch ( error ) {
			props.IP = req.connection.remoteAddress;
		}
	}

	// Render the view
	res.render('demos/'+demo, props, function(err, html) {
		if(err) { next(err); }

		// If we're wanting a download... force headers
		if(download) {
			res.header('Cache-Control', 'public');
			res.header('Content-Description', 'File Transfer');
			res.header('Content-Disposition', 'attachment; filename="'+demo+'".html');
			res.header('Content-Type', 'application/html');
			res.header('Content-Transfer-Encoding', 'binary');
		}

		// If we're wanting to see the source... we need to do som processing!
		else if(source) {
			singleline = html.replace(/\n/g,'\uffff');

			function sanitize(regex) {
				return singleline.match(regex).join("\n")
					.replace(/\uffff/g,"\n")
					.replace(/https?:\/\/media[0-9]\.juggledesign\.com\/.*?\/(\w+)/g, '/path/to/$1')
					.replace(/https?:\/\/craigsworks.com\/.*?\/(\w+)/g, '/path/to/$1');
			}

			res.render('layouts/source', {
				js: sanitize(/<script type="text\/javascript"[^>]*>(.*?)<\/script>/gi),
				css: sanitize(/<link rel="stylesheet"[^>]*?\/?>|<style type="text\/css"[^>]*>(.*?)<\/style>/gi),
				html: sanitize(/<body[^>]*>(.*?)<!-- JavaScript\(s\)-->/gi)
			});
		}

		// Just send content on regular request
		else { res.send(html); }
	});
}

/*
 * Download
 */
exports.download = function(req, res) {
	// Grab commit message
	var file = path.join(paths.build, 'commitmsg'),
		sizes = fs.readFileSync( path.join(paths.build, 'filesizes') ),
		commitmsg = fs.readFileSync(file),
		mtime = fs.statSync(file).mtime;

	// Render
	res.render('download', {
		title: ['Download'],
		page: 'download',
		nightly: {
			commitmsg: commitmsg,
			mtime: mtime
		},
		sizes: sizes
	});
}

/* 
 * Download builder
 */
exports.build = function(req, res) {
	// Shout (if shouting)!
	if(req.body.shoutout) {
		shout(req.body.shoutout, false);
	}

	// Build it
	build.apply(build, arguments);
}

/*
 * Donate
 */
exports.donate = function(req, res) {
	res.render('donate', {
		title: ['Donate'],
		page: 'donate'
	});
}

/*
 * Converter
 */
exports.converter = function(req, res) {
	res.render('converter', {
		title: ['v1.0 Code Converter'],
		page: 'converter'
	});
}


/*
 * Documentation
 */
exports.docs = function(req, res, next) {
	var page = req.params.page || '',
		plugin = req.params.plugin || '',
		dir = path.join(paths.git.nightly, 'docs'),
		file = path.join(dir, (page || 'gettingstarted'), plugin) + '.md';

	// Open file if it exists
	if(fs.existsSync(file)) {
		content = fs.readFileSync(file, 'utf-8');

		// Convert .md to .html
		content = markdown.makeHtml(content)
			.replace(/\n/g,'\uffff')
			.replace(/<code([^>]*)>(.*?)<\/code>/gm, function(original, props, source){
				var lang = /class="(\w+)"/.exec(props), code = source.replace(/\uffff/g,"\n");
				return '<code'+props+'>'+nsh.highlight(code, nsh.getLanguage(lang && lang[1] || 'js'));+'</code>';
			})
			.replace(/\uffff/g,"\n");
	}

	// Otherwise throw an error and continue
	else { return next(new Error('Unable to find documentation ' + file)); }

	res.render('docs/', {
		title: ['Documentation', page.substr(0,1).toUpperCase() + page.substr(1) ],
		page: 'docs',
		content: content
	});
}

/*
 * "Where are you using qTip2?" handler
 */
exports.where = function(req, res) {
	var params = req.body || {};

	// Shout it if we have proper params
	if(params.name && params.where) {
		shout(params);
	}

	// Redirect back to the referring page
	res.redirect( req.header('Referer') );
}