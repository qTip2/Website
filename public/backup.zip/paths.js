var path = require('path');

/*
 * Paths for use in other modules
 */
module.exports = {
	logs: path.resolve('./log'),
	build: path.resolve('./build'),
	git: {
		nightly: path.resolve('./build/nightly/'),
		stable: path.resolve('./build/stable')
	}
}