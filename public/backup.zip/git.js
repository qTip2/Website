var paths = require('./paths')
	, Q = require('q')
	, util = require('util')
	, fs = require('fs')
	, path = require('path')
	, cp = require('child_process')
	, glob = require('glob-whatev');

// File list to generate file sizes for and it's JSON key mapping
var _files = {
	'core.js': 'core',
	'../../jquery.min.js': 'jquery',
	'*/*.js': 'plugins[%s]',
	'core.css': 'styles[core]',
	'basic.css': 'styles[basic]',
	'css3.css': 'styles[css3]'
};

/*
 * GitHub update
 * 
 * Updates the git repositories and generates new file size
 * mappings and commit message for download page
 */
function update() {
	// Grab the JSON payload
	var fileSizes = { stable: {}, nightly: {} }, result = Q.resolve();

	// For both nightly and stable repos
	console.log('Updating reps and parsing src file sizes...');
	['nightly', 'stable'].forEach(function(version) {
		// Pull newest commits
		result = result.then(function() {
			console.log('Pulling %s repo...', version);
			return Q.ninvoke(cp, 'exec', 'git pull', {
				cwd: paths.git[version],
				stdio: [0,1,2]
			});
		})

		// Generate file size listings
		result = result.then(function() {
			for(pattern in _files) {
				var filepath = path.join(paths.git[version], 'src', pattern);

				// Locate files and loop over
				glob.glob( filepath ).forEach(function(file) {
					var subject = _files[pattern];

					// Grab fileesize and set
					result = result.then(function() {
						return Q.ninvoke(fs, 'stat', file).then(function(stats) {
							// Generate object key from pattern and file basename
							var key = subject.indexOf('%s') > -1 ?
								util.format(subject, path.basename(file, '.js')) : subject;

							// Set the key
							fileSizes[version][key] = stats.size;
						});
					});
				});
			}
		});
	});

	// Upon completion, log out file sizes to build/filesizes
	result.then(function() {
		console.log('Generating file size JSON...')
		return Q.ninvoke(fs, 'writeFile',
			path.join(paths.build, 'filesizes'),
			JSON.stringify(fileSizes)
		);
	})

	// Generate cached commit message in build folder
	.then(function() {
		console.log('Caching latest commit message...')
		var filepath = path.resolve(paths.build, 'commitmsg');
		return Q.ninvoke(cp, 'exec', 'git log --pretty=format:\'%s\' -1 > ' + filepath, {
			cwd: paths.git.nightly
		});
	})

	// Record on complete/failure
	.fin(function() { console.log('Done.'); })
	.fail(function(err) {
		console.error('Error: %s', err);
	});
}

function hook(res, req, next) {
	// GitHub Post hook IPs: 207.97.227.253, 50.57.128.197, 108.171.174.178
	var githubIPs = /207\.97\.227\.253|50\.57\.128\.197|108\.171\.174\.178/;

	// Only allow GitHub IP's through
	if(!githubIPs.test(req.ip)) { return res.redirect('/'); }

	console.log('POST hook from GitHub received, updating...');
	module.exports.update();
}

module.exports = {
	hook: hook,
	update: update
} 