var paths = require('./paths'),
	Q = require('q'),
	cp = require('child_process'),
	tmp = require('tmp'),
	fs = require('fs'),
	path = require('path'),
	util = require('util'),
	zipstream = require('zipstream');

// Additional file paths
var jquery = path.resolve('./build/jquery.min.js');

/* 
 * Init
 */
function init(res, params) {
	// Setup styles to include
	var styles = [];
	for(style in params.styles) { styles.push(style); }

	// Setup plugins to include
	var plugins = [];
	for(plugin in params.plugins) { plugins.push(plugin); }

	// Create temp directory to build into
	tmp.dir(function(err, tmpdir) {
		console.log('Grunting files...');

		// Spawn grunt process
		var grunt = cp.spawn('grunt', [
			'--dist='+tmpdir,
			'--plugins='+(plugins.join(' ') || ''),
			'--styles='+(styles.join(' ') || '')
		], {
			cwd: paths.git.nightly
		});

		// When all grunt-ed...
		grunt.on('exit', function(code) {

			// Get tmp directory file listing
			Q.ninvoke(fs, 'readdir', tmpdir)

			// Convert grunt-ed files to absolute file paths
			.then(function(files) {
				console.log('Parsing file paths...');

				files.forEach(function(file, i) {
					files[i] = path.resolve(tmpdir, file);
				});
				return files;
			})

			// Add additional zip contents based on params
			.then(function(files) {
				process.stdout.write('Adding additional files... ');

				// Add jQuery if enabled
				if(params.jq || params.jquery) {
					process.stdout.write('jQuery ');
					files.unshift(jquery);
				}

				process.stdout.write("\n");
				return files;
			})

			// Once grunt-ed, create our zip file
			.then(function(files) {
				console.log('Streaming zip file...');

				// Set the response headers
				res.set({
					'Pragma': 'public',
					'Expires': '0',
					'Cache-Control': 'must-revalidate, post-check=0, pre-check=0',
					'Cache-Control': 'public',
					'Content-Description': 'File Transfer',
					'Content-type': 'application/zip',
					'Content-Disposition': 'attachment; filename="jquery.qtip.zip"'
				});

				// Construct the zip on the fly
				return constructZip(res, files);
			})

			// Done. Cleanup temporary files/dir
			.then(function(files) {
				var result = Q.resolve();

				console.log('Done! Cleaning up temporary files...');

				// Delete all files within the temp directory
				files.forEach(function(file) {
					if( path.relative(tmpdir, file).substr(0,2) !== '..' ) {
						result = Q.ninvoke(fs, 'unlink', file);
					}
					else { result = Q.resolve(); }
				});

				// Attempt to remove the temp directory itself
				result.then(function() {
					return Q.ninvoke(fs, 'rmdir', tmpdir);
				});

				return result;
			})

			// Redirect to download page on error
			.fail(function(err) {
				res.redirect('download/error');
			});
		});
	});
}


/*
 * Dynamic zip constructor / caching
 */
function constructZip(res, files) {
	var deferred = Q.defer(), zip, result;

	// Create new zip stream
	zip = zipstream.createZip({ level: 1 }); 

	// Write out response to server on stream write
	zip.on('data', function(data) { res.write(data); });

	// When the stream ends close server response
	zip.on('end', function() { res.end(); });

	// Loop through all other files and add them sequentially using promises
	result = Q.resolve();
	files.forEach(function(file) {
		result = result.then(function() {
			// If file is found, add it
			if(fs.existsSync(file)) {
				//console.log('Adding file: ', file);
				return Q.ncall(zip.addFile, zip, fs.createReadStream(file), {
					name: path.basename(file)
				});
			}

			// File wasn't found...
			else {
				console.log('Cannot locate file: ', file, '. Skipping...');
				return Q.resolve();
			}
		});
	});

	// Finalize the zip file when done
	result.then(function() {
		zip.finalize();
		deferred.resolve(files);
	});

	return deferred.promise;
}

exports.build = function(req, res) {
	init(res, req.body);
};